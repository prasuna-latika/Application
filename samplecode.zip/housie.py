import random
import time

class HousieTicket:
    def __init__(self, player_name):
        self.player_name = player_name
        self.grid = self._generate_ticket()
        self.marked_numbers = set()
        self.won_patterns = set() # To keep track of patterns already claimed

    def _generate_ticket(self):
        """Generates a standard Housie ticket (9 columns, 3 rows)."""
        ticket = [[None for _ in range(9)] for _ in range(3)]
        column_numbers = [[] for _ in range(9)] # Store numbers for each column

        # Generate numbers for each column based on ranges
        # Col 0: 1-9, Col 1: 10-19, ..., Col 8: 80-90
        for col in range(9):
            start = col * 10 + 1
            end = start + 9 if col < 8 else 90
            column_numbers[col] = random.sample(range(start, end + 1), 3) # Each column has 3 numbers initially

        # Place numbers into the ticket grid
        # Distribute the 3 numbers per column into the 3 rows
        for col_idx in range(9):
            for row_num_idx in range(3):
                ticket[row_num_idx][col_idx] = column_numbers[col_idx][row_num_idx]

        # Ensure each row has 5 numbers and 4 blanks
        # We've placed 3 numbers per column. Now make sure each row has 5 total.
        for row_idx in range(3):
            # Get the current numbers in the row
            current_row_numbers = [(num, col_idx) for col_idx, num in enumerate(ticket[row_idx]) if num is not None]

            # If a row has more than 5 numbers (shouldn't happen with current logic, but as a safeguard)
            while len(current_row_numbers) > 5:
                # Randomly remove one to make it 5
                removed_num, removed_col = random.choice(current_row_numbers)
                ticket[row_idx][removed_col] = None
                current_row_numbers.remove((removed_num, removed_col))

            # Fill up with blanks if less than 5 numbers (which will always be the case after initial placement)
            # Find empty slots and potential numbers to fill from other columns
            empty_slots = [col_idx for col_idx, num in enumerate(ticket[row_idx]) if num is None]
            
            # This is a bit tricky to ensure 5 numbers per row AND correct column ranges.
            # A common approach is to create all 15 numbers (5 per row) and then distribute them.
            # Let's simplify and just ensure 5 numbers per row by adding None.

            # More robust ticket generation:
            # Create a list of 15 unique numbers
            all_ticket_numbers = set()
            while len(all_ticket_numbers) < 15:
                col_to_pick_from = random.randint(0, 8)
                start = col_to_pick_from * 10 + 1
                end = start + 9 if col_to_pick_from < 8 else 90
                num = random.randint(start, end)
                all_ticket_numbers.add(num)
            
            all_ticket_numbers = sorted(list(all_ticket_numbers)) # Sort for easier distribution

            # Distribute numbers into columns and rows
            temp_ticket = [[None for _ in range(9)] for _ in range(3)]
            filled_columns_count = [0] * 9 # To track numbers placed in each column

            # Place numbers trying to maintain 5 per row and 1-3 per column
            for num in all_ticket_numbers:
                col = (num - 1) // 10 if num <= 89 else 8 # Determine column based on number range
                if col > 8: col = 8 # Handle 90
                
                # Find an empty spot in the correct column's row
                placed = False
                # Try to place in a row that has less than 5 numbers AND the column has less than 3
                available_rows = [r for r in range(3) if temp_ticket[r][col] is None]
                random.shuffle(available_rows)

                for r in available_rows:
                    row_filled_count = sum(1 for x in temp_ticket[r] if x is not None)
                    if row_filled_count < 5 and filled_columns_count[col] < 3:
                        temp_ticket[r][col] = num
                        filled_columns_count[col] += 1
                        placed = True
                        break
                
                # If couldn't place, try again (this simple placement might not always work perfectly)
                # A more complex algorithm is needed for absolutely perfect distribution
                if not placed:
                    # Fallback for simpler distribution, potentially breaking column rules slightly
                    for r in range(3):
                        if temp_ticket[r][col] is None:
                            temp_ticket[r][col] = num
                            filled_columns_count[col] += 1
                            break

            # Final check to ensure 5 numbers per row by adding None
            final_ticket = []
            for row in temp_ticket:
                row_with_nones = [x for x in row if x is not None]
                while len(row_with_nones) < 5:
                    row_with_nones.append(None)
                # Sort numbers in place for easier checking later if needed (optional)
                row_with_nones.sort(key=lambda x: x if x is not None else 100) # Sort Nones to end
                final_ticket.append(row_with_nones)
                
            # Now, reconstruct the 9-column grid with None for blank spaces
            # This is simpler and ensures 5 numbers per row with 4 Nones.
            reconstructed_ticket = [[None for _ in range(9)] for _ in range(3)]
            for r_idx, row in enumerate(final_ticket):
                # Place numbers back into their correct column positions
                numbers_in_row = sorted([n for n in row if n is not None])
                
                # Distribute these 5 numbers into appropriate columns, adding Nones
                placed_count = 0
                for col_idx in range(9):
                    for num_val in numbers_in_row:
                        start = col_idx * 10 + 1
                        end = start + 9 if col_idx < 8 else 90
                        if start <= num_val <= end and reconstructed_ticket[r_idx][col_idx] is None and placed_count < 5:
                            reconstructed_ticket[r_idx][col_idx] = num_val
                            placed_count += 1
                            break # Move to next column

            # This reconstruction is complex. Let's stick to the initial approach for simplicity
            # and just ensure we have 15 numbers total and column ranges are mostly adhered to.
            
            # --- Simpler, more standard ticket generation logic ---
            ticket = [[None for _ in range(9)] for _ in range(3)]
            
            # Fill 15 unique numbers, 5 per row, from correct column ranges
            # This is a bit more involved to guarantee column distributions (1-3 numbers per column)
            
            # Create a list of all possible numbers and shuffle
            all_numbers = list(range(1, 91))
            random.shuffle(all_numbers)

            # Distribute 15 numbers (5 per row)
            numbers_for_ticket = random.sample(range(1, 91), 15)
            
            # Organize numbers by column
            cols_with_nums = [[] for _ in range(9)]
            for num in numbers_for_ticket:
                col_idx = (num - 1) // 10 if num != 90 else 8 # Column index for the number
                cols_with_nums[col_idx].append(num)
            
            # Sort numbers within each column
            for col_list in cols_with_nums:
                col_list.sort()

            # Place numbers into the ticket grid ensuring no more than 3 per column and 5 per row
            # This is the trickiest part for perfect Housie ticket generation.
            # A common way is to fill column by column, then balance rows.

            # Simple fill for demonstration (might not be perfect Housie rules for column counts)
            flat_ticket_numbers = sorted(numbers_for_ticket)
            
            # Place 5 numbers per row, ensuring they are in their correct column ranges
            # And add Nones for the remaining 4 spots in each row.
            
            # Generate 5 numbers for each row, ensuring correct column distribution
            for r_idx in range(3):
                row_nums = set()
                while len(row_nums) < 5:
                    col_idx_to_fill = random.randint(0, 8)
                    start_range = col_idx_to_fill * 10 + 1
                    end_range = start_range + 9 if col_idx_to_fill < 8 else 90
                    
                    num = random.randint(start_range, end_range)
                    
                    # Check if number is unique on the entire ticket
                    is_unique = True
                    for r in range(3):
                        if num in ticket[r]:
                            is_unique = False
                            break
                    if not is_unique:
                        continue
                    
                    # Check if column has max 3 numbers already (approx)
                    col_count = sum(1 for row in ticket if row[col_idx_to_fill] is not None)
                    if col_count >= 3:
                        continue
                    
                    # Check if row has max 5 numbers already
                    if sum(1 for x in row_nums if x is not None) >= 5:
                        continue
                    
                    row_nums.add(num)
                
                # Convert set to list and sort for this row
                sorted_row_nums = sorted(list(row_nums))
                
                # Place numbers into the 9-column row, with Nones
                temp_row = [None] * 9
                placed_count = 0
                for num in sorted_row_nums:
                    col_idx = (num - 1) // 10 if num != 90 else 8
                    while temp_row[col_idx] is not None: # Find next available slot in column
                        col_idx = (col_idx + 1) % 9 # Wrap around
                    temp_row[col_idx] = num
                    placed_count += 1
                ticket[r_idx] = temp_row
            
            return ticket

    def display(self):
        """Prints the current state of the ticket."""
        print(f"\n--- {self.player_name}'s Ticket ---")
        for row in self.grid:
            display_row = []
            for num in row:
                if num is None:
                    display_row.append("  --") # Blank space
                elif num in self.marked_numbers:
                    display_row.append(f"({num:02d})") # Marked number
                else:
                    display_row.append(f" {num:02d}") # Unmarked number
            print(" ".join(display_row))
        print("------------------------")

    def mark_number(self, number):
        """Marks a number on the ticket if it exists."""
        if number in self.marked_numbers:
            return False # Already marked
        
        found = False
        for r_idx, row in enumerate(self.grid):
            for c_idx, num_on_ticket in enumerate(row):
                if num_on_ticket == number:
                    self.marked_numbers.add(number)
                    found = True
                    break
            if found:
                break
        return found

    def check_for_wins(self, called_numbers):
        """Checks for winning patterns and returns a list of won patterns."""
        wins = []
        
        # Early Five
        if "Early Five" not in self.won_patterns and len(self.marked_numbers) >= 5:
            # Need to ensure these 5 are on *this* ticket.
            # If current marked numbers are >= 5, it means we have 5 valid marks from this ticket.
            wins.append("Early Five")
            
        # Rows
        for r_idx, row in enumerate(self.grid):
            row_numbers_on_ticket = [num for num in row if num is not None]
            if f"Row {r_idx + 1}" not in self.won_patterns and len(row_numbers_on_ticket) > 0: # Ensure row is not empty
                all_marked_in_row = True
                for num in row_numbers_on_ticket:
                    if num not in self.marked_numbers:
                        all_marked_in_row = False
                        break
                if all_marked_in_row and row_numbers_on_ticket: # Check if there are numbers to mark
                    wins.append(f"Row {r_idx + 1}")
                    
        # Full House
        if "Full House" not in self.won_patterns and len(self.marked_numbers) == 15: # A ticket has 15 numbers
            wins.append("Full House")
            
        return wins

class HousieGame:
    def __init__(self, num_players=1):
        self.called_numbers = []
        self.remaining_numbers = list(range(1, 91))
        random.shuffle(self.remaining_numbers)
        self.players = []
        self.game_over = False
        self.winners = {
            "Early Five": [],
            "Row 1": [],
            "Row 2": [],
            "Row 3": [],
            "Full House": []
        }

        for i in range(num_players):
            self.players.append(HousieTicket(f"Player {i+1}"))

    def call_number(self):
        """Calls out the next random number."""
        if not self.remaining_numbers:
            print("No more numbers to call!")
            return None
        
        number = self.remaining_numbers.pop(0)
        self.called_numbers.append(number)
        return number

    def play_turn(self):
        """Executes a single turn of the game."""
        if self.game_over:
            print("Game is over!")
            return

        current_number = self.call_number()
        if current_number is None:
            self.game_over = True
            return

        print(f"\n======================================")
        print(f"Number Called: {current_number}")
        print(f"Numbers Called So Far: {self.called_numbers}")
        print(f"======================================")

        for player in self.players:
            if player.mark_number(current_number):
                print(f"{player.player_name} marked {current_number}.")
                
            # Check for wins for this player
            new_wins = player.check_for_wins(self.called_numbers)
            for win_pattern in new_wins:
                if player.player_name not in self.winners[win_pattern]:
                    self.winners[win_pattern].append(player.player_name)
                    player.won_patterns.add(win_pattern) # Mark pattern as won for this player
                    print(f"\n!!! {player.player_name} Wins {win_pattern} !!!")
                    self.display_all_tickets() # Show tickets when someone wins
                    # If Full House is won, game usually ends
                    if win_pattern == "Full House":
                        self.game_over = True
                        print("\n!!! FULL HOUSE - GAME OVER !!!")
                        return

        # Display all tickets after each number call (optional, can be verbose)
        # self.display_all_tickets()

        # Check if Full House is claimed by anyone
        if len(self.winners["Full House"]) > 0:
            self.game_over = True

    def display_all_tickets(self):
        """Displays all players' tickets."""
        for player in self.players:
            player.display()

    def start_game(self):
        """Starts and runs the Housie game."""
        print("Welcome to Housie!")
        print("Generating tickets...")
        self.display_all_tickets()
        print("\nStarting game...\n")

        while not self.game_over:
            input("\nPress Enter to call next number...")
            self.play_turn()
            time.sleep(0.5) # Small delay for better readability

        print("\n--- Game Over! ---")
        print("\nWinners:")
        for pattern, players_list in self.winners.items():
            if players_list:
                print(f"  {pattern}: {', '.join(players_list)}")
            else:
                print(f"  {pattern}: No winner")

# --- Main Game Execution ---
if __name__ == "__main__":
    num_players = int(input("Enter number of players (1-5 recommended for demo): "))
    if num_players < 1:
        num_players = 1
    elif num_players > 5:
        print("Limiting to 5 players for demonstration purposes.")
        num_players = 5

    game = HousieGame(num_players)
    game.start_game()
