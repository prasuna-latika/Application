import random

class Player:
    def __init__(self, name):
        self.name = name
        self.position = 0  # Starting position (usually 0 or 1 before the actual board)
        self.has_won = False

    def __repr__(self):
        return f"{self.name} (Pos: {self.position})"

class SnakeAndLaddersGame:
    def __init__(self, num_players=2, board_size=100):
        self.board_size = board_size
        self.players = [Player(f"Player {i+1}") for i in range(num_players)]
        self.current_player_index = 0
        self.game_over = False

        # Define snakes: (start_square, end_square)
        # Snakes make you go down
        self.snakes = {
            16: 6,
            47: 26,
49: 11,
            56: 53,
            62: 19,
            64: 60,
            87: 24,
            93: 73,
            95: 75,
            98: 78
        }

        # Define ladders: (start_square, end_square)
        # Ladders make you go up
        self.ladders = {
            1: 38,
            4: 14,
            9: 31,
            21: 42,
            28: 84,
            36: 44,
            51: 67,
            71: 91,
            80: 100
        }

        print(f"Game initialized with {num_players} players.")
        print("Snakes:", self.snakes)
        print("Ladders:", self.ladders)

    def roll_dice(self):
        return random.randint(1, 6)

    def move_player(self, player, dice_roll):
        old_position = player.position
        new_position = old_position + dice_roll

        print(f"{player.name} rolled a {dice_roll}.")
        print(f"{player.name} moves from {old_position} to {new_position}.")

        # Handle going over the board_size
        if new_position > self.board_size:
            print(f"{player.name} cannot move past {self.board_size}. Stays at {old_position}.")
            player.position = old_position # Player stays at old position if they overshoot
            return

        player.position = new_position

        # Check for snakes and ladders
        if player.position in self.snakes:
            snake_head = player.position
            snake_tail = self.snakes[player.position]
            player.position = snake_tail
            print(f"Oh no! {player.name} landed on a snake at {snake_head} and slides down to {snake_tail}!")
        elif player.position in self.ladders:
            ladder_bottom = player.position
            ladder_top = self.ladders[player.position]
            player.position = ladder_top
            print(f"Yay! {player.name} found a ladder at {ladder_bottom} and climbs up to {ladder_top}!")

        print(f"{player.name}'s new position: {player.position}")

        # Check for win condition
        if player.position == self.board_size:
            player.has_won = True
            self.game_over = True
            print(f"\n*** {player.name} has reached {self.board_size} and WINS THE GAME! ***")

    def play_turn(self):
        if self.game_over:
            return

        current_player = self.players[self.current_player_index]
        print(f"\n--- {current_player.name}'s Turn (Current Pos: {current_player.position}) ---")

        input("Press Enter to roll the dice...")
        dice_roll = self.roll_dice()
        self.move_player(current_player, dice_roll)

        if not self.game_over:
            # Switch to the next player
            self.current_player_index = (self.current_player_index + 1) % len(self.players)

    def start_game(self):
        while not self.game_over:
            self.play_turn()

# --- Main Game Execution ---
if __name__ == "__main__":
    game = SnakeAndLaddersGame(num_players=2)
    game.start_game()
