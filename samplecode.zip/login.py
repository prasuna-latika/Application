import tkinter as tk
from tkinter import messagebox
import csv
import os

def login():
    username = e1.get()
    password = e2.get()
    if username == "hani" and password == "123":
        messagebox.showinfo("Login Successful", f"Welcome, {username}!")
    else:
        messagebox.showerror("Login Failed", "Invalid credentials. Please sign up first.")

def signup():
    def save_user():
        username = e_username.get()
        password = e_password.get()
        if username and password:
            with open("users.csv", mode="a", newline="") as file:
                writer = csv.writer(file)
                writer.writerow([username, password])
            messagebox.showinfo("Sign Up Successful", "Your account has been created.")
            signup_window.destroy()
        else:
            messagebox.showerror("Input Error", "Please fill in both fields.")

    signup_window = tk.Toplevel(root)
    signup_window.title("Sign Up")

    tk.Label(signup_window, text="Username:").pack()
    e_username = tk.Entry(signup_window)
    e_username.pack()

    tk.Label(signup_window, text="Password:").pack()
    e_password = tk.Entry(signup_window, show="*")
    e_password.pack()

    tk.Button(signup_window, text="Sign Up", command=save_user).pack()
    tk.Button(signup_window, text="Cancel", command=signup_window.destroy).pack()
root = tk.Tk()
root.geometry('400x300')
root.title("Login Application")

tk.Label(root, text="Login Page", font=("Helvetica", 16)).pack(pady=20)

tk.Label(root, text="Username:").pack()
e1 = tk.Entry(root)
e1.pack()

tk.Label(root, text="Password:").pack()
e2 = tk.Entry(root, show="*")
e2.pack()

tk.Button(root, text="Login", command=login).pack(pady=10)
tk.Button(root, text="Sign Up", command=signup).pack()

root.mainloop()
