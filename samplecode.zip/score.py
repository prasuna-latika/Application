score=int(input("enter score:"))
if score==6:
    print("hit six")
elif score==4:
    print("Hit four")
elif score==5:
    print("five runs")
elif score==3:
    print("three runs")
elif  score==2:
    print("two runs")
elif score==1:
    print("one run")
elif score==0:
    print("no ball/wide")
else:
    print("wicket")
