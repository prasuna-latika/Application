import tkinter as tk
import time
import random

# Sample texts to type
texts = [
    "The quick brown fox jumps over the lazy dog.",
    "Typing fast and accurately takes practice.",
    "Python is a versatile programming language.",
    "Artificial intelligence is changing the world.",
    "Practice makes perfect in every skill."
]

class TypingTestApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Typing Speed Test")
        self.root.geometry("600x400")
        self.root.resizable(False, False)

        self.text_to_type = random.choice(texts)
        self.start_time = None

        self.create_widgets()

    def create_widgets(self):
        # Display text
        self.label = tk.Label(self.root, text="Type the following text:", font=("Arial", 14))
        self.label.pack(pady=10)

        self.display = tk.Message(self.root, text=self.text_to_type, font=("Arial", 12), width=500)
        self.display.pack(pady=10)

        # Input box
        self.entry = tk.Text(self.root, height=5, width=60, font=("Arial", 12))
        self.entry.pack(pady=10)
        self.entry.bind("<FocusIn>", self.start_timer)

        # Result
        self.result_label = tk.Label(self.root, text="", font=("Arial", 12))
        self.result_label.pack(pady=10)

        # Button
        self.button = tk.Button(self.root, text="Done", command=self.calculate_result, font=("Arial", 12))
        self.button.pack()

    def start_timer(self, event=None):
        if not self.start_time:
            self.start_time = time.time()

    def calculate_result(self):
        end_time = time.time()
        total_time = end_time - self.start_time if self.start_time else 1

        typed_text = self.entry.get("1.0", tk.END).strip()
        words_typed = typed_text.split()
        correct_words = self.text_to_type.split()

        correct_count = sum(1 for i, word in enumerate(words_typed) if i < len(correct_words) and word == correct_words[i])
        accuracy = (correct_count / len(correct_words)) * 100 if correct_words else 0
        wpm = (len(words_typed) / total_time) * 60

        self.result_label.config(
            text=f"WPM: {wpm:.2f} | Accuracy: {accuracy:.2f}%"
        )

        # Disable typing
        self.entry.config(state="disabled")

if __name__ == "__main__":
    root = tk.Tk()
    app = TypingTestApp(root)
    root.mainloop()
