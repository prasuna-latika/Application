import pygame
import random

# --- Pygame Initialization ---
pygame.init()

# --- Screen Dimensions ---
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Classic Snake Game")

# --- Colors ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0) # Snake color
RED = (255, 0, 0)   # Food color
BLUE = (0, 0, 255)  # Game over message color
DARK_GREEN = (0, 150, 0) # Snake border

# --- Game Constants ---
GRID_SIZE = 20 # Size of each square (snake segment, food)
SNAKE_SPEED = 10 # Frames per second (higher means faster)
INITIAL_SNAKE_LENGTH = 3

# --- Directions ---
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

# --- Fonts ---
font_score = pygame.font.Font(None, 36)
font_game_over = pygame.font.Font(None, 72)
font_restart = pygame.font.Font(None, 48)

# --- Game Classes ---

class Snake:
    def __init__(self):
        self.body = [(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)] # Initial head position
        self.direction = RIGHT # Initial direction
        self.grow = False # Flag to indicate if snake should grow
        for _ in range(INITIAL_SNAKE_LENGTH - 1): # Add initial body segments
            self.body.append((self.body[-1][0] - GRID_SIZE, self.body[-1][1]))

    def move(self):
        """Moves the snake by adding a new head and removing the tail."""
        head_x, head_y = self.body[0]
        new_head = (head_x + self.direction[0] * GRID_SIZE,
                    head_y + self.direction[1] * GRID_SIZE)
        self.body.insert(0, new_head) # Add new head

        if not self.grow:
            self.body.pop() # Remove tail if not growing
        else:
            self.grow = False # Reset grow flag

    def change_direction(self, new_direction):
        """Changes the snake's direction, preventing immediate reverse."""
        if (new_direction[0] * -1, new_direction[1] * -1) != self.direction:
            self.direction = new_direction

    def check_collision(self):
        """Checks for collision with walls or itself."""
        head_x, head_y = self.body[0]

        # Wall collision
        if not (0 <= head_x < SCREEN_WIDTH and 0 <= head_y < SCREEN_HEIGHT):
            return True

        # Self collision (start checking from the 4th segment to avoid immediate self-collision)
        if self.body[0] in self.body[1:]:
            return True
        
        return False

    def draw(self, screen):
        """Draws the snake on the screen."""
        for segment in self.body:
            pygame.draw.rect(screen, GREEN, (segment[0], segment[1], GRID_SIZE, GRID_SIZE))
            pygame.draw.rect(screen, DARK_GREEN, (segment[0], segment[1], GRID_SIZE, GRID_SIZE), 1) # Border

class Food:
    def __init__(self):
        self.position = self.generate_random_position()

    def generate_random_position(self):
        """Generates a random position for the food on the grid."""
        x = random.randrange(0, SCREEN_WIDTH // GRID_SIZE) * GRID_SIZE
        y = random.randrange(0, SCREEN_HEIGHT // GRID_SIZE) * GRID_SIZE
        return (x, y)

    def draw(self, screen):
        """Draws the food on the screen."""
        pygame.draw.rect(screen, RED, (self.position[0], self.position[1], GRID_SIZE, GRID_SIZE))

# --- Main Game Loop ---
def main():
    snake = Snake()
    food = Food()
    score = 0
    game_over = False
    clock = pygame.time.Clock()

    # --- Restart Button ---
    restart_button_text = font_restart.render("Play Again", True, WHITE)
    restart_button_rect = restart_button_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 100))

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if not game_over:
                    if event.key == pygame.K_UP:
                        snake.change_direction(UP)
                    elif event.key == pygame.K_DOWN:
                        snake.change_direction(DOWN)
                    elif event.key == pygame.K_LEFT:
                        snake.change_direction(LEFT)
                    elif event.key == pygame.K_RIGHT:
                        snake.change_direction(RIGHT)
                elif game_over and event.key == pygame.K_r: # 'R' to restart
                    game_over = False
                    snake = Snake()
                    food = Food()
                    score = 0
            if event.type == pygame.MOUSEBUTTONDOWN and game_over:
                if restart_button_rect.collidepoint(event.pos):
                    game_over = False
                    snake = Snake()
                    food = Food()
                    score = 0

        if not game_over:
            snake.move()

            # Check for food collision
            if snake.body[0] == food.position:
                score += 1
                snake.grow = True
                food.position = food.generate_random_position()
                # Ensure food doesn't spawn on snake
                while food.position in snake.body:
                    food.position = food.generate_random_position()

            # Check for game over
            if snake.check_collision():
                game_over = True

        # --- Drawing ---
        screen.fill(BLACK) # Clear screen

        snake.draw(screen)
        food.draw(screen)

        # Display score
        score_text = font_score.render(f"Score: {score}", True, WHITE)
        screen.blit(score_text, (10, 10))

        if game_over:
            game_over_text = font_game_over.render("Game Over!", True, BLUE)
            game_over_rect = game_over_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))
            screen.blit(game_over_text, game_over_rect)

            pygame.draw.rect(screen, GREEN, restart_button_rect, 0, 10) # Button background
            pygame.draw.rect(screen, WHITE, restart_button_rect, 2, 10) # Button border
            screen.blit(restart_button_text, restart_button_rect)


        pygame.display.flip() # Update the full display Surface to the screen

        clock.tick(SNAKE_SPEED) # Control game speed

    pygame.quit()
    print("Game Closed.")

if __name__ == "__main__":
    main()
