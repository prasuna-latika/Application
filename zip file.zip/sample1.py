import tkinter as tk
root = tk.tk()
root.geometry('300x200')
root.mainloop()