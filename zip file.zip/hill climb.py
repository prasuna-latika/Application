import pygame
import random
import math

# --- Pygame Initialization ---
pygame.init()

# --- Screen Dimensions ---
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Hill Climb")

# --- Colors ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 200, 0) # Ground color
DARK_GREEN = (0, 150, 0)
BLUE = (100, 100, 255) # Sky color
RED = (255, 0, 0)   # Car color
GRAY = (100, 100, 100) # Wheel color

# --- Game Constants ---
FPS = 60
GRAVITY = 0.2
CAR_ACCELERATION = 0.1
CAR_BRAKE_DECELERATION = 0.2
CAR_FRICTION = 0.05 # Slows car down naturally
CAR_ANGULAR_SPEED = 2 # How fast the car rotates

# --- Terrain Generation ---
TERRAIN_POINTS = []
TERRAIN_DETAIL = 50 # Number of points to define the terrain
TERRAIN_MAX_HEIGHT_DIFFERENCE = 100
TERRAIN_SMOOTHNESS = 0.5 # Higher means smoother transitions

def generate_terrain():
    """Generates a simple hilly terrain."""
    global TERRAIN_POINTS
    TERRAIN_POINTS = []
    # Start point
    TERRAIN_POINTS.append((0, SCREEN_HEIGHT - 100))

    current_height = SCREEN_HEIGHT - 100
    for i in range(1, TERRAIN_DETAIL):
        x = i * (SCREEN_WIDTH * 3 // TERRAIN_DETAIL) # Make terrain wider than screen
        
        # Generate next height based on previous, with some randomness
        min_height = max(SCREEN_HEIGHT - 300, current_height - TERRAIN_MAX_HEIGHT_DIFFERENCE)
        max_height = min(SCREEN_HEIGHT - 50, current_height + TERRAIN_MAX_HEIGHT_DIFFERENCE)
        
        next_height = random.randint(int(min_height), int(max_height))
        
        # Smooth transition
        current_height = current_height * TERRAIN_SMOOTHNESS + next_height * (1 - TERRAIN_SMOOTHNESS)
        TERRAIN_POINTS.append((x, int(current_height)))

    # Add an end point far away
    TERRAIN_POINTS.append((TERRAIN_POINTS[-1][0] + 500, TERRAIN_POINTS[-1][1]))
    TERRAIN_POINTS.append((TERRAIN_POINTS[-1][0] + 500, SCREEN_HEIGHT - 50)) # Ensure a flat end

# --- Car Class ---
class Car:
    def __init__(self):
        self.width = 60
        self.height = 30
        self.x = SCREEN_WIDTH // 4 # Start position
        self.y = 0 # Will be set to terrain height
        self.angle = 0 # Radians
        self.speed = 0
        self.angular_velocity = 0 # For rotation

        self.front_wheel_offset = self.width / 2 - 10
        self.rear_wheel_offset = -self.width / 2 + 10
        self.wheel_radius = 10

        self.on_ground = False
        self.game_over = False

    def get_rotated_points(self):
        """Calculates the rotated corners of the car for drawing."""
        points = [
            (-self.width / 2, -self.height / 2),
            (self.width / 2, -self.height / 2),
            (self.width / 2, self.height / 2),
            (-self.width / 2, self.height / 2)
        ]
        
        rotated_points = []
        for px, py in points:
            rotated_x = px * math.cos(self.angle) - py * math.sin(self.angle)
            rotated_y = px * math.sin(self.angle) + py * math.cos(self.angle)
            rotated_points.append((self.x + rotated_x, self.y + rotated_y))
        return rotated_points

    def get_wheel_positions(self):
        """Calculates the positions of the wheels."""
        # Relative to car center, then rotated and translated
        front_wheel_x_rel = self.front_wheel_offset * math.cos(self.angle) - (self.height / 2) * math.sin(self.angle)
        front_wheel_y_rel = self.front_wheel_offset * math.sin(self.angle) + (self.height / 2) * math.cos(self.angle)

        rear_wheel_x_rel = self.rear_wheel_offset * math.cos(self.angle) - (self.height / 2) * math.sin(self.angle)
        rear_wheel_y_rel = self.rear_wheel_offset * math.sin(self.angle) + (self.height / 2) * math.cos(self.angle)

        front_wheel_pos = (self.x + front_wheel_x_rel, self.y + front_wheel_y_rel)
        rear_wheel_pos = (self.x + rear_wheel_x_rel, self.y + rear_wheel_y_rel)
        
        return front_wheel_pos, rear_wheel_pos

    def update(self, terrain_offset):
        """Updates car's physics and position."""
        if self.game_over:
            return

        # Apply gravity
        self.speed -= GRAVITY * math.sin(self.angle) # Gravity affects speed on slopes
        self.y += GRAVITY # Simple vertical gravity effect

        # Apply friction
        if self.on_ground:
            self.speed *= (1 - CAR_FRICTION)
            if abs(self.speed) < 0.1: # Stop if speed is very low
                self.speed = 0

        # Update position based on speed
        self.x += self.speed * math.cos(self.angle)
        self.y += self.speed * math.sin(self.angle)

        # Update angle based on angular velocity
        self.angle += self.angular_velocity
        self.angular_velocity *= 0.9 # Dampen angular velocity

        # Terrain collision (simplified)
        # Find the terrain height at the car's current x position
        car_bottom_y = self.y + self.height / 2 * math.cos(self.angle) # Approximate lowest point of car
        
        terrain_height_at_car = get_terrain_height(self.x + terrain_offset)

        if car_bottom_y >= terrain_height_at_car:
            self.y = terrain_height_at_car - self.height / 2 * math.cos(self.angle) # Place car on terrain
            self.on_ground = True
            self.angular_velocity = 0 # Stop rotation when on ground
            
            # Align car angle with terrain slope
            # Find slope by checking a point slightly ahead
            look_ahead_x = self.x + terrain_offset + self.width / 4 # Small offset to get slope
            look_behind_x = self.x + terrain_offset - self.width / 4
            
            height_ahead = get_terrain_height(look_ahead_x)
            height_behind = get_terrain_height(look_behind_x)
            
            # Calculate slope angle
            slope_angle = math.atan2(height_ahead - height_behind, (look_ahead_x - look_behind_x))
            self.angle = slope_angle # Align car with terrain
            
            # Prevent car from "sticking" too much when going downhill very slowly
            if self.speed == 0 and abs(self.angle) > math.pi / 4: # If stuck on steep slope
                self.speed += GRAVITY * math.sin(self.angle) * 0.5 # Give it a little push downhill
        else:
            self.on_ground = False
            # If in air, apply gravity to speed_y
            self.speed -= GRAVITY # Apply gravity when not on ground

        # Check for car flip (game over)
        if abs(self.angle) > math.pi / 2 + 0.1: # If angle exceeds 90 degrees (plus a small buffer)
            self.game_over = True

    def accelerate(self):
        """Increases car's forward speed."""
        self.speed += CAR_ACCELERATION

    def brake(self):
        """Decreases car's speed (or moves backward)."""
        self.speed -= CAR_ACCELERATION

    def balance_forward(self):
        """Rotates car forward (nose down)."""
        self.angular_velocity -= math.radians(CAR_ANGULAR_SPEED)

    def balance_backward(self):
        """Rotates car backward (nose up)."""
        self.angular_velocity += math.radians(CAR_ANGULAR_SPEED)

    def draw(self, screen, terrain_offset):
        """Draws the car and its wheels."""
        # Draw car body
        rotated_points = self.get_rotated_points()
        # Adjust points by terrain_offset for drawing relative to camera
        draw_points = [(px - terrain_offset, py) for px, py in rotated_points]
        pygame.draw.polygon(screen, RED, draw_points)
        pygame.draw.polygon(screen, BLACK, draw_points, 2) # Border

        # Draw wheels
        front_wheel_pos, rear_wheel_pos = self.get_wheel_positions()
        
        # Adjust wheel positions by terrain_offset for drawing
        draw_front_wheel_pos = (front_wheel_pos[0] - terrain_offset, front_wheel_pos[1])
        draw_rear_wheel_pos = (rear_wheel_pos[0] - terrain_offset, rear_wheel_pos[1])

        pygame.draw.circle(screen, GRAY, (int(draw_front_wheel_pos[0]), int(draw_front_wheel_pos[1])), self.wheel_radius)
        pygame.draw.circle(screen, BLACK, (int(draw_front_wheel_pos[0]), int(draw_front_wheel_pos[1])), self.wheel_radius, 1)

        pygame.draw.circle(screen, GRAY, (int(draw_rear_wheel_pos[0]), int(draw_rear_wheel_pos[1])), self.wheel_radius)
        pygame.draw.circle(screen, BLACK, (int(draw_rear_wheel_pos[0]), int(draw_rear_wheel_pos[1])), self.wheel_radius, 1)

# --- Terrain Helper Functions ---
def get_terrain_height(x_coord):
    """
    Returns the y-coordinate (height) of the terrain at a given x-coordinate.
    Interpolates between terrain points.
    """
    for i in range(len(TERRAIN_POINTS) - 1):
        p1_x, p1_y = TERRAIN_POINTS[i]
        p2_x, p2_y = TERRAIN_POINTS[i+1]

        if p1_x <= x_coord <= p2_x:
            # Linear interpolation
            if p2_x == p1_x: # Avoid division by zero
                return p1_y
            
            t = (x_coord - p1_x) / (p2_x - p1_x)
            return p1_y + t * (p2_y - p1_y)
    
    # If x_coord is beyond the generated terrain, assume flat ground at the last point's height
    if x_coord < TERRAIN_POINTS[0][0]:
        return TERRAIN_POINTS[0][1]
    return TERRAIN_POINTS[-1][1]

def draw_terrain(screen, terrain_offset):
    """Draws the terrain polygons."""
    if not TERRAIN_POINTS:
        return

    # Create points for the ground polygon
    ground_points = []
    for i in range(len(TERRAIN_POINTS)):
        x, y = TERRAIN_POINTS[i]
        ground_points.append((x - terrain_offset, y))
    
    # Add bottom corners to close the polygon
    ground_points.append((ground_points[-1][0], SCREEN_HEIGHT))
    ground_points.append((ground_points[0][0], SCREEN_HEIGHT))

    pygame.draw.polygon(screen, GREEN, ground_points)
    pygame.draw.polygon(screen, DARK_GREEN, ground_points, 2) # Border

# --- Main Game Loop ---
def main():
    generate_terrain()
    car = Car()
    
    # Set initial car Y position on the terrain
    car.y = get_terrain_height(car.x) - car.height / 2

    terrain_offset = 0 # How much the terrain has scrolled

    game_over = False
    running = True
    clock = pygame.time.Clock()

    # --- Restart Button ---
    font_game_over = pygame.font.Font(None, 72)
    font_restart = pygame.font.Font(None, 48)
    restart_button_text = font_restart.render("Restart", True, WHITE)
    restart_button_rect = restart_button_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 100))

    while running:
        # --- Event Handling ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if not game_over:
                    if event.key == pygame.K_RIGHT:
                        car.accelerate()
                    elif event.key == pygame.K_LEFT:
                        car.brake()
                    elif event.key == pygame.K_UP: # Balance forward (nose down)
                        car.balance_forward()
                    elif event.key == pygame.K_DOWN: # Balance backward (nose up)
                        car.balance_backward()
                elif event.key == pygame.K_r: # 'R' to restart
                    generate_terrain()
                    car = Car()
                    car.y = get_terrain_height(car.x) - car.height / 2
                    terrain_offset = 0
                    game_over = False
            if event.type == pygame.KEYUP:
                if not game_over:
                    if event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
                        car.speed *= 0.5 # Reduce speed quickly on key release
                    if event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                        car.angular_velocity *= 0.5 # Reduce angular speed quickly

            if event.type == pygame.MOUSEBUTTONDOWN and game_over:
                if restart_button_rect.collidepoint(event.pos):
                    generate_terrain()
                    car = Car()
                    car.y = get_terrain_height(car.x) - car.height / 2
                    terrain_offset = 0
                    game_over = False

        # --- Game Logic ---
        if not game_over:
            car.update(terrain_offset)
            if car.game_over: # Check if car flipped during update
                game_over = True

            # Adjust terrain offset to keep car somewhat centered horizontally
            target_offset = car.x - SCREEN_WIDTH // 4
            terrain_offset += (target_offset - terrain_offset) * 0.05 # Smooth camera follow
            
            # Prevent terrain_offset from going negative (left boundary)
            if terrain_offset < 0:
                terrain_offset = 0
            # Prevent terrain_offset from going too far right (beyond terrain end)
            if TERRAIN_POINTS:
                max_terrain_x = TERRAIN_POINTS[-1][0]
                if terrain_offset > max_terrain_x - SCREEN_WIDTH + car.width: # Adjust for screen width and car width
                    terrain_offset = max_terrain_x - SCREEN_WIDTH + car.width
                    if terrain_offset < 0: terrain_offset = 0 # Handle cases where terrain is smaller than screen

        # --- Drawing ---
        screen.fill(BLUE) # Sky background

        draw_terrain(screen, terrain_offset)
        car.draw(screen, terrain_offset)

        # Display game over message
        if game_over:
            game_over_text = font_game_over.render("GAME OVER!", True, RED)
            game_over_rect = game_over_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))
            screen.blit(game_over_text, game_over_rect)

            # Draw restart button
            pygame.draw.rect(screen, GREEN, restart_button_rect, 0, 10) # Button background
            pygame.draw.rect(screen, WHITE, restart_button_rect, 2, 10) # Button border
            screen.blit(restart_button_text, restart_button_rect)

        pygame.display.flip() # Update the full display Surface to the screen

        clock.tick(FPS) # Control frame rate

    pygame.quit()
    print("Hill Climb Game Closed.")

if __name__ == "__main__":
    main()
