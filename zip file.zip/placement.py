import tkinter as tk


root=tk.Tk()
root.geometry('2000x900')
root.title("my application")
root.config(bg='powder blue')


m1=tk.Label(root,text="welcome to students profile",font=("algerian", 20 ,"bold"))
m1.place(x=500,y=50)

m2=tk.Label(root,text="student name",font=("algerian", 16),bg='pink')
m2.place(x=500,y=100)

e1=tk.Entry(root,font=("algerian", 16))
e1.place(x=700,y=100)

m3=tk.Label(root,text="student id",font=("algerian",  16),bg='light green')
m3.place(x=500,y=200)

e2=tk.Entry(root,font=("arial", 16))
e2.place(x=700,y=200)

m4=tk.Label(root,text="cgpa",font=("arial", 16),bg='orange')
m4.place(x=500,y=300)

e3=tk.Entry(root,font=("arial", 16))
e3.place(x=700,y=300)

b1=tk.Button(root,text="submit",font=("italic", 16))
b1.place(x=600,y=400)

b2=tk.Button(root,text="cancel",font=("italic", 16))
b2.place(x=700,y=400)
root.mainloop()

