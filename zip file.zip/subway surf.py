import pygame

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Simple Pygame Concept")

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

# Player properties
player_width = 50
player_height = 50
player_x = SCREEN_WIDTH // 2 - player_width // 2
player_y = SCREEN_HEIGHT - player_height - 10
player_speed = 5
player_jump_power = -15
gravity = 0.8
player_y_velocity = 0

is_jumping = False

# Game loop
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not is_jumping:
                player_y_velocity = player_jump_power
                is_jumping = True

    # Handle player horizontal movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player_x -= player_speed
    if keys[pygame.K_RIGHT]:
        player_x += player_speed

    # Apply gravity
    player_y += player_y_velocity
    player_y_velocity += gravity

    # Prevent player from going off screen horizontally
    if player_x < 0:
        player_x = 0
    if player_x > SCREEN_WIDTH - player_width:
        player_x = SCREEN_WIDTH - player_width

    # Ground collision
    if player_y >= SCREEN_HEIGHT - player_height - 10:
        player_y = SCREEN_HEIGHT - player_height - 10
        player_y_velocity = 0
        is_jumping = False

    # Drawing
    screen.fill(BLUE)  # Background color
    pygame.draw.rect(screen, RED, (player_x, player_y, player_width, player_height)) # Draw player

    # Update display
    pygame.display.flip()

    # Cap frame rate
    clock.tick(60) # 60 frames per second

pygame.quit()
