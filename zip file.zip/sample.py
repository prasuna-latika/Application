score=int(input("enter score:"))
if score==6:
    print("hit six")
elif score==4:
    print("Hit four")
elif  score==2:
    print("two runs")
elif score==1:
    print("one run")
elif score==0:
    print("no ball/wide")
else:
    print("wicket")