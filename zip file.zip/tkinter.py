import tkinter as tk

root = tk.Tk()
root.geometry('200x100')

root.mainloop()
